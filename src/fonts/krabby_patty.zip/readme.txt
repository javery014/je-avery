Krabby Patty v1.0

This is meant to be for personal use only, because even though
it's "unofficial" it's basically an exact copy of the font used
in the game. I don't know if there was a license for it, but just
to be safe please don't include this font in anything you're
planning to sell or make money off of (such as games, monetized
YouTube videos, T-shirts, etc.)

Oh, and don't sell this font either.

Thanks.

Contact: pslehisl@gmail.com